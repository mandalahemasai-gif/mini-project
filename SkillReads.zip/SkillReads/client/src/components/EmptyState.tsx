import { Button } from "@/components/ui/button";
import { BookOpen, Plus, Search } from "lucide-react";

interface EmptyStateProps {
  type: "no-resources" | "no-results";
  onAddResource?: () => void;
  onClearFilters?: () => void;
}

export default function EmptyState({ type, onAddResource, onClearFilters }: EmptyStateProps) {
  if (type === "no-resources") {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
        <div className="rounded-full bg-muted p-6 mb-6">
          <BookOpen className="w-12 h-12 text-muted-foreground" />
        </div>
        <h3 className="text-2xl font-semibold mb-2">No Resources Yet</h3>
        <p className="text-muted-foreground mb-6 max-w-md">
          Get started by adding your first educational resource to the library.
        </p>
        {onAddResource && (
          <Button onClick={onAddResource} data-testid="button-add-first-resource">
            <Plus className="mr-2 h-4 w-4" />
            Add Your First Resource
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="rounded-full bg-muted p-6 mb-6">
        <Search className="w-12 h-12 text-muted-foreground" />
      </div>
      <h3 className="text-2xl font-semibold mb-2">No Results Found</h3>
      <p className="text-muted-foreground mb-6 max-w-md">
        We couldn't find any resources matching your search criteria. Try adjusting your filters or search terms.
      </p>
      {onClearFilters && (
        <Button onClick={onClearFilters} variant="outline" data-testid="button-clear-filters-empty">
          Clear Filters
        </Button>
      )}
    </div>
  );
}
