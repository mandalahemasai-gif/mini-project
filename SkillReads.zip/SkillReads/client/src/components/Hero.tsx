import { Button } from "@/components/ui/button";
import { BookOpen, GraduationCap, Target } from "lucide-react";
import { heroImage } from "@/lib/categoryImages";

interface HeroProps {
  onBrowseClick: () => void;
  resourceCount: number;
}

export default function Hero({ onBrowseClick, resourceCount }: HeroProps) {
  return (
    <div className="relative h-96 md:h-[500px] w-full overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      
      <div className="relative h-full flex flex-col items-center justify-center text-center px-4 max-w-4xl mx-auto">
        <div className="flex items-center gap-2 mb-4">
          <GraduationCap className="w-12 h-12 text-white" />
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white font-sans">
            EduLibrary
          </h1>
        </div>
        
        <p className="text-xl md:text-2xl text-white/95 mb-2 font-sans">
          Discover Educational Resources
        </p>
        <p className="text-base md:text-lg text-white/85 mb-8 max-w-2xl leading-relaxed">
          Access curated learning materials organized by skill level. Whether you're a beginner or advancing your expertise, find the perfect resources for your journey.
        </p>
        
        <Button 
          size="lg"
          onClick={onBrowseClick}
          className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border-2 border-white/30 text-lg px-8 py-6 h-auto"
          data-testid="button-browse-resources"
        >
          <BookOpen className="mr-2 h-5 w-5" />
          Browse Resources
        </Button>
        
        <div className="flex flex-wrap items-center justify-center gap-6 mt-12 text-white/90">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            <span className="text-sm font-medium">{resourceCount} Resources</span>
          </div>
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            <span className="text-sm font-medium">6 Categories</span>
          </div>
          <div className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5" />
            <span className="text-sm font-medium">3 Skill Levels</span>
          </div>
        </div>
      </div>
    </div>
  );
}
