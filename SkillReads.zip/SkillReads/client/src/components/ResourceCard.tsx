import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { type Resource } from "@shared/schema";
import { BookOpen, Tag, Video } from "lucide-react";
import { isVideoUrl } from "@/lib/videoUtils";

interface ResourceCardProps {
  resource: Resource;
  onClick: () => void;
}

const skillLevelColors = {
  Beginner: "bg-emerald-500 text-white",
  Intermediate: "bg-amber-500 text-white",
  Advanced: "bg-rose-500 text-white",
};

export default function ResourceCard({ resource, onClick }: ResourceCardProps) {
  return (
    <Card 
      className="group cursor-pointer overflow-hidden hover-elevate active-elevate-2 transition-all duration-200 h-full flex flex-col"
      onClick={onClick}
      data-testid={`card-resource-${resource.id}`}
    >
      <div className="relative aspect-video overflow-hidden">
        <img 
          src={resource.imageUrl} 
          alt={resource.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {isVideoUrl(resource.videoUrl) && (
          <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm rounded-full p-2">
            <Video className="w-5 h-5 text-white" data-testid={`icon-video-${resource.id}`} />
          </div>
        )}
        <Badge 
          className={`absolute top-4 right-4 ${skillLevelColors[resource.skillLevel as keyof typeof skillLevelColors]} text-xs font-bold uppercase tracking-wide shadow-lg`}
          data-testid={`badge-skill-${resource.id}`}
        >
          {resource.skillLevel}
        </Badge>
      </div>
      
      <CardHeader className="flex-none pb-3">
        <h3 className="text-xl font-semibold leading-tight line-clamp-2 group-hover:text-primary transition-colors" data-testid={`text-title-${resource.id}`}>
          {resource.title}
        </h3>
      </CardHeader>
      
      <CardContent className="flex-1 pb-4">
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2" data-testid={`text-description-${resource.id}`}>
          {resource.description}
        </p>
      </CardContent>
      
      <CardFooter className="flex items-center justify-between gap-2 pt-0 flex-wrap">
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Tag className="w-4 h-4" />
          <span data-testid={`text-category-${resource.id}`}>{resource.category}</span>
        </div>
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <BookOpen className="w-4 h-4" />
          <span data-testid={`text-type-${resource.id}`}>{resource.resourceType}</span>
        </div>
      </CardFooter>
    </Card>
  );
}
