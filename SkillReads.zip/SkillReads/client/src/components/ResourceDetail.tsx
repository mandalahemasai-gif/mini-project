import { type Resource } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ArrowLeft, BookOpen, Edit, Tag, Trash2, Video } from "lucide-react";
import { getVideoEmbedUrl, isVideoUrl } from "@/lib/videoUtils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface ResourceDetailProps {
  resource: Resource;
  onBack: () => void;
  onEdit: () => void;
  onDelete: () => void;
  isDeleting?: boolean;
}

const skillLevelColors = {
  Beginner: "bg-emerald-500 text-white",
  Intermediate: "bg-amber-500 text-white",
  Advanced: "bg-rose-500 text-white",
};

export default function ResourceDetail({ resource, onBack, onEdit, onDelete, isDeleting }: ResourceDetailProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 flex-wrap">
        <Button 
          variant="ghost" 
          onClick={onBack}
          disabled={isDeleting}
          data-testid="button-back"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Resources
        </Button>
      </div>

      {isVideoUrl(resource.videoUrl) ? (
        <div className="space-y-4">
          <div className="relative rounded-md overflow-hidden aspect-video bg-black">
            <iframe
              src={getVideoEmbedUrl(resource.videoUrl!) || undefined}
              title={resource.title}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              data-testid="video-player"
            />
            <Badge 
              className={`absolute top-6 right-6 ${skillLevelColors[resource.skillLevel as keyof typeof skillLevelColors]} text-sm font-bold uppercase tracking-wide shadow-lg px-4 py-2`}
              data-testid="badge-skill-level"
            >
              {resource.skillLevel}
            </Badge>
          </div>
          <div className="relative h-60 rounded-md overflow-hidden">
            <img 
              src={resource.imageUrl} 
              alt={resource.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      ) : (
        <div className="relative h-80 rounded-md overflow-hidden">
          <img 
            src={resource.imageUrl} 
            alt={resource.title}
            className="w-full h-full object-cover"
          />
          <Badge 
            className={`absolute top-6 right-6 ${skillLevelColors[resource.skillLevel as keyof typeof skillLevelColors]} text-sm font-bold uppercase tracking-wide shadow-lg px-4 py-2`}
            data-testid="badge-skill-level"
          >
            {resource.skillLevel}
          </Badge>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div>
            <h1 className="text-4xl font-bold mb-4" data-testid="text-resource-title">{resource.title}</h1>
            <p className="text-base leading-relaxed text-foreground" data-testid="text-resource-description">
              {resource.description}
            </p>
          </div>

          <div className="flex gap-4 flex-wrap">
            <Button onClick={onEdit} disabled={isDeleting} data-testid="button-edit">
              <Edit className="mr-2 h-4 w-4" />
              Edit Resource
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" disabled={isDeleting} data-testid="button-delete">
                  <Trash2 className="mr-2 h-4 w-4" />
                  {isDeleting ? "Deleting..." : "Delete Resource"}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the resource "{resource.title}".
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={isDeleting} data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={onDelete} disabled={isDeleting} data-testid="button-confirm-delete">
                    {isDeleting ? "Deleting..." : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold">Resource Information</h3>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Tag className="w-5 h-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground mb-1">Category</p>
                  <p className="font-medium" data-testid="text-category">{resource.category}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <BookOpen className="w-5 h-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground mb-1">Resource Type</p>
                  <p className="font-medium" data-testid="text-resource-type">{resource.resourceType}</p>
                </div>
              </div>

              {isVideoUrl(resource.videoUrl) && (
                <div className="flex items-start gap-3">
                  <Video className="w-5 h-5 mt-0.5 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-muted-foreground mb-1">Video Content</p>
                    <p className="font-medium text-primary">Available</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
