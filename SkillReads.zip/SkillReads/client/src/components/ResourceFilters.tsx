import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, X } from "lucide-react";
import { categories, skillLevels } from "@shared/schema";
import { Button } from "@/components/ui/button";

interface ResourceFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategories: string[];
  onCategoryToggle: (category: string) => void;
  selectedSkillLevels: string[];
  onSkillLevelToggle: (level: string) => void;
  onClearFilters: () => void;
}

const skillLevelColors = {
  Beginner: "bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/20 border-emerald-500/30",
  Intermediate: "bg-amber-500/10 text-amber-700 hover:bg-amber-500/20 border-amber-500/30",
  Advanced: "bg-rose-500/10 text-rose-700 hover:bg-rose-500/20 border-rose-500/30",
};

export default function ResourceFilters({
  searchQuery,
  onSearchChange,
  selectedCategories,
  onCategoryToggle,
  selectedSkillLevels,
  onSkillLevelToggle,
  onClearFilters,
}: ResourceFiltersProps) {
  const hasActiveFilters = selectedCategories.length > 0 || selectedSkillLevels.length > 0 || searchQuery.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-muted-foreground" />
          <h3 className="text-lg font-semibold">Filters</h3>
        </div>
        {hasActiveFilters && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onClearFilters}
            className="text-sm"
            data-testid="button-clear-filters"
          >
            <X className="w-4 h-4 mr-1" />
            Clear All
          </Button>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="search" className="text-sm font-medium">Search Resources</Label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            id="search"
            type="search"
            placeholder="Search by title or description..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10"
            data-testid="input-search"
          />
        </div>
      </div>

      <div className="space-y-3">
        <Label className="text-sm font-medium">Skill Level</Label>
        <div className="flex flex-wrap gap-2">
          {skillLevels.map((level) => (
            <Badge
              key={level}
              variant={selectedSkillLevels.includes(level) ? "default" : "outline"}
              className={`cursor-pointer text-xs font-bold uppercase tracking-wide px-3 py-1.5 ${
                selectedSkillLevels.includes(level) 
                  ? skillLevelColors[level as keyof typeof skillLevelColors].replace('hover:bg-', 'bg-').split(' ')[0]
                  : skillLevelColors[level as keyof typeof skillLevelColors]
              }`}
              onClick={() => onSkillLevelToggle(level)}
              data-testid={`filter-skill-${level.toLowerCase()}`}
            >
              {level}
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <Label className="text-sm font-medium">Categories</Label>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category} className="flex items-center space-x-2">
              <Checkbox
                id={category}
                checked={selectedCategories.includes(category)}
                onCheckedChange={() => onCategoryToggle(category)}
                data-testid={`filter-category-${category.toLowerCase()}`}
              />
              <label
                htmlFor={category}
                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                {category}
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
