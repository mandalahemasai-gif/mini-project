import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertResourceSchema, type InsertResource, categories, skillLevels } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Save } from "lucide-react";
import { getCategoryImage } from "@/lib/categoryImages";

interface ResourceFormProps {
  initialData?: InsertResource;
  onSubmit: (data: InsertResource) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export default function ResourceForm({ initialData, onSubmit, onCancel, isLoading }: ResourceFormProps) {
  const form = useForm<InsertResource>({
    resolver: zodResolver(insertResourceSchema),
    defaultValues: initialData ? {
      title: initialData.title,
      description: initialData.description,
      category: initialData.category,
      skillLevel: initialData.skillLevel,
      imageUrl: initialData.imageUrl,
      resourceType: initialData.resourceType,
      videoUrl: initialData.videoUrl || "",
    } : {
      title: "",
      description: "",
      category: "Programming",
      skillLevel: "Beginner",
      imageUrl: "",
      resourceType: "",
      videoUrl: "",
    },
  });

  const selectedCategory = form.watch("category");

  const handleCategoryChange = (category: string) => {
    form.setValue("category", category as any);
    if (!form.getValues("imageUrl")) {
      const imageUrl = getCategoryImage(category, 0);
      form.setValue("imageUrl", imageUrl);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 flex-wrap">
        <Button 
          variant="ghost" 
          onClick={onCancel}
          type="button"
          data-testid="button-cancel"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Cancel
        </Button>
      </div>

      <div>
        <h2 className="text-3xl font-bold">
          {initialData ? "Edit Resource" : "Add New Resource"}
        </h2>
        <p className="text-muted-foreground mt-2">
          {initialData ? "Update the resource details below" : "Fill in the details to add a new educational resource"}
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g., Introduction to Python Programming" 
                      {...field} 
                      data-testid="input-title"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="resourceType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Resource Type</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="e.g., Video Course, eBook, Tutorial" 
                      {...field} 
                      data-testid="input-resource-type"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Provide a detailed description of this educational resource..."
                    className="min-h-32 resize-none"
                    {...field}
                    data-testid="input-description"
                  />
                </FormControl>
                <FormDescription>
                  Minimum 10 characters, maximum 1000 characters
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid gap-6 md:grid-cols-2">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select 
                    onValueChange={handleCategoryChange} 
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="skillLevel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Skill Level</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-skill-level">
                        <SelectValue placeholder="Select skill level" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {skillLevels.map((level) => (
                        <SelectItem key={level} value={level}>
                          {level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="imageUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Image URL</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="https://example.com/image.jpg" 
                    {...field} 
                    data-testid="input-image-url"
                  />
                </FormControl>
                <FormDescription>
                  {selectedCategory && `Auto-filled with ${selectedCategory} image. You can change it if needed.`}
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          {form.watch("imageUrl") && (
            <div className="rounded-md overflow-hidden border">
              <img 
                src={form.watch("imageUrl")} 
                alt="Preview"
                className="w-full h-48 object-cover"
                onError={(e) => {
                  e.currentTarget.src = "https://placehold.co/600x400?text=Invalid+Image+URL";
                }}
              />
            </div>
          )}

          <FormField
            control={form.control}
            name="videoUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Video URL (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="https://www.youtube.com/watch?v=... or https://vimeo.com/..." 
                    {...field} 
                    data-testid="input-video-url"
                  />
                </FormControl>
                <FormDescription>
                  Add a YouTube or Vimeo URL to include video content with this resource
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex gap-4 flex-wrap">
            <Button 
              type="submit" 
              disabled={isLoading}
              data-testid="button-submit"
            >
              <Save className="mr-2 h-4 w-4" />
              {isLoading ? (initialData ? "Updating..." : "Adding...") : (initialData ? "Update Resource" : "Add Resource")}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
              disabled={isLoading}
              data-testid="button-cancel-form"
            >
              Cancel
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
