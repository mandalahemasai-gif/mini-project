import programmingImg1 from '@assets/stock_images/programming_code_on__bd853788.jpg';
import programmingImg2 from '@assets/stock_images/programming_code_on__fe211c3a.jpg';
import programmingImg3 from '@assets/stock_images/programming_code_on__3dd28a01.jpg';
import mathImg1 from '@assets/stock_images/mathematics_equation_29c12190.jpg';
import mathImg2 from '@assets/stock_images/mathematics_equation_cf3eca2f.jpg';
import mathImg3 from '@assets/stock_images/mathematics_equation_808b1283.jpg';
import scienceImg1 from '@assets/stock_images/science_laboratory_c_0d5e6746.jpg';
import scienceImg2 from '@assets/stock_images/science_laboratory_c_24a5b389.jpg';
import scienceImg3 from '@assets/stock_images/science_laboratory_c_d79fb010.jpg';
import languagesImg1 from '@assets/stock_images/languages_learning_b_ce171d01.jpg';
import languagesImg2 from '@assets/stock_images/languages_learning_b_5bc24eae.jpg';
import languagesImg3 from '@assets/stock_images/languages_learning_b_6bf3fb7f.jpg';
import businessImg1 from '@assets/stock_images/business_economics_f_3382a144.jpg';
import businessImg2 from '@assets/stock_images/business_economics_f_08235ca0.jpg';
import artsImg1 from '@assets/stock_images/art_design_creative__d6ce82bd.jpg';
import artsImg2 from '@assets/stock_images/art_design_creative__647069eb.jpg';
import heroImg from '@assets/stock_images/diverse_students_stu_28306b1e.jpg';

export const categoryImages: Record<string, string[]> = {
  Programming: [programmingImg1, programmingImg2, programmingImg3],
  Mathematics: [mathImg1, mathImg2, mathImg3],
  Science: [scienceImg1, scienceImg2, scienceImg3],
  Languages: [languagesImg1, languagesImg2, languagesImg3],
  Business: [businessImg1, businessImg2],
  Arts: [artsImg1, artsImg2],
};

export const heroImage = heroImg;

export function getCategoryImage(category: string, index: number = 0): string {
  const images = categoryImages[category] || categoryImages.Programming;
  return images[index % images.length];
}
