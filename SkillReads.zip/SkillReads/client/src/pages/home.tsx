import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { type Resource, type InsertResource } from "@shared/schema";
import Hero from "@/components/Hero";
import ResourceCard from "@/components/ResourceCard";
import ResourceFilters from "@/components/ResourceFilters";
import ResourceDetail from "@/components/ResourceDetail";
import ResourceForm from "@/components/ResourceForm";
import EmptyState from "@/components/EmptyState";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

type View = "browse" | "detail" | "add" | "edit";

export default function Home() {
  const [view, setView] = useState<View>("browse");
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedSkillLevels, setSelectedSkillLevels] = useState<string[]>([]);
  const resourcesRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: resources = [], isLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertResource) => {
      return await apiRequest("POST", "/api/resources", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      toast({
        title: "Success",
        description: "Resource added successfully",
      });
      setView("browse");
      scrollToResources();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add resource",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: InsertResource }) => {
      return await apiRequest("PATCH", `/api/resources/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      toast({
        title: "Success",
        description: "Resource updated successfully",
      });
      setView("browse");
      scrollToResources();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update resource",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/resources/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      setView("browse");
      setTimeout(() => {
        toast({
          title: "Success",
          description: "Resource deleted successfully",
        });
        scrollToResources();
      }, 100);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete resource",
        variant: "destructive",
      });
    },
  });

  const scrollToResources = () => {
    setTimeout(() => {
      resourcesRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const filteredResources = resources.filter((resource) => {
    const matchesSearch = 
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = 
      selectedCategories.length === 0 || selectedCategories.includes(resource.category);
    
    const matchesSkillLevel = 
      selectedSkillLevels.length === 0 || selectedSkillLevels.includes(resource.skillLevel);
    
    return matchesSearch && matchesCategory && matchesSkillLevel;
  });

  const handleCategoryToggle = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  const handleSkillLevelToggle = (level: string) => {
    setSelectedSkillLevels((prev) =>
      prev.includes(level)
        ? prev.filter((l) => l !== level)
        : [...prev, level]
    );
  };

  const handleClearFilters = () => {
    setSearchQuery("");
    setSelectedCategories([]);
    setSelectedSkillLevels([]);
  };

  const handleResourceClick = (resource: Resource) => {
    setSelectedResource(resource);
    setView("detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleEdit = () => {
    setView("edit");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = () => {
    if (selectedResource) {
      deleteMutation.mutate(selectedResource.id);
    }
  };

  const handleSubmit = (data: InsertResource) => {
    if (view === "edit" && selectedResource) {
      updateMutation.mutate({ id: selectedResource.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const isFormLoading = createMutation.isPending || updateMutation.isPending;
  const isDeleteLoading = deleteMutation.isPending;

  const handleBrowseClick = () => {
    scrollToResources();
  };

  const handleAddNew = () => {
    setSelectedResource(null);
    setView("add");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (view === "detail" && selectedResource) {
    return (
      <div className="min-h-screen">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <ResourceDetail
            resource={selectedResource}
            onBack={() => {
              if (!isDeleteLoading) {
                setView("browse");
              }
            }}
            onEdit={() => {
              if (!isDeleteLoading) {
                handleEdit();
              }
            }}
            onDelete={handleDelete}
            isDeleting={isDeleteLoading}
          />
        </div>
      </div>
    );
  }

  if (view === "add" || view === "edit") {
    const editData = view === "edit" && selectedResource ? {
      title: selectedResource.title,
      description: selectedResource.description,
      category: selectedResource.category,
      skillLevel: selectedResource.skillLevel,
      imageUrl: selectedResource.imageUrl,
      resourceType: selectedResource.resourceType,
      videoUrl: selectedResource.videoUrl || "",
    } as InsertResource : undefined;

    return (
      <div className="min-h-screen">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <ResourceForm
            initialData={editData}
            onSubmit={handleSubmit}
            onCancel={() => {
              if (!isFormLoading) {
                setView("browse");
              }
            }}
            isLoading={isFormLoading}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Hero onBrowseClick={handleBrowseClick} resourceCount={resources.length} />
      
      <div ref={resourcesRef} className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
          <div>
            <h2 className="text-3xl font-bold">Browse Resources</h2>
            <p className="text-muted-foreground mt-1">
              {filteredResources.length} {filteredResources.length === 1 ? "resource" : "resources"} available
            </p>
          </div>
          <Button 
            onClick={handleAddNew} 
            disabled={isFormLoading || isDeleteLoading}
            data-testid="button-add-resource"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Resource
          </Button>
        </div>

        <div className="grid gap-8 lg:grid-cols-4">
          <aside className="lg:col-span-1">
            <div className="sticky top-4">
              <ResourceFilters
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                selectedCategories={selectedCategories}
                onCategoryToggle={handleCategoryToggle}
                selectedSkillLevels={selectedSkillLevels}
                onSkillLevelToggle={handleSkillLevelToggle}
                onClearFilters={handleClearFilters}
              />
            </div>
          </aside>

          <main className="lg:col-span-3">
            {isLoading ? (
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="aspect-video w-full" />
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                ))}
              </div>
            ) : filteredResources.length === 0 ? (
              <EmptyState
                type={resources.length === 0 ? "no-resources" : "no-results"}
                onAddResource={resources.length === 0 ? handleAddNew : undefined}
                onClearFilters={resources.length > 0 ? handleClearFilters : undefined}
              />
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3" data-testid="grid-resources">
                {filteredResources.map((resource) => (
                  <ResourceCard
                    key={resource.id}
                    resource={resource}
                    onClick={() => handleResourceClick(resource)}
                  />
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
