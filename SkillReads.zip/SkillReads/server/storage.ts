import { type Resource, type InsertResource } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getAllResources(): Promise<Resource[]>;
  getResource(id: string): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  updateResource(id: string, resource: InsertResource): Promise<Resource | undefined>;
  deleteResource(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private resources: Map<string, Resource>;

  constructor() {
    this.resources = new Map();
    this.seedData();
  }

  private seedData() {
    const seedResources: InsertResource[] = [
      {
        title: "Python for Beginners: Complete Guide",
        description: "Learn Python programming from scratch with this comprehensive guide. Covers variables, data types, control structures, functions, and basic object-oriented programming concepts. Perfect for absolute beginners with no prior coding experience.",
        category: "Programming",
        skillLevel: "Beginner",
        imageUrl: "/attached_assets/stock_images/programming_code_on__bd853788.jpg",
        resourceType: "Video Course",
        videoUrl: "https://www.youtube.com/watch?v=rfscVS0vtbw",
      },
      {
        title: "Advanced Data Structures in Python",
        description: "Master complex data structures including trees, graphs, heaps, and hash tables. Learn advanced algorithms for sorting, searching, and optimization. Includes real-world applications and interview preparation materials for experienced developers.",
        category: "Programming",
        skillLevel: "Advanced",
        imageUrl: "/attached_assets/stock_images/programming_code_on__fe211c3a.jpg",
        resourceType: "eBook",
      },
      {
        title: "Calculus I: Limits and Derivatives",
        description: "Introduction to differential calculus covering limits, continuity, derivatives, and their applications. Includes numerous examples, practice problems, and step-by-step solutions to build strong mathematical foundations.",
        category: "Mathematics",
        skillLevel: "Intermediate",
        imageUrl: "/attached_assets/stock_images/mathematics_equation_29c12190.jpg",
        resourceType: "Online Course",
        videoUrl: "https://www.youtube.com/watch?v=WUvTyaaNkzM",
      },
      {
        title: "Basic Algebra and Arithmetic",
        description: "Fundamental mathematics covering addition, subtraction, multiplication, division, fractions, decimals, and basic algebra. Designed for students building essential math skills with clear explanations and practice exercises.",
        category: "Mathematics",
        skillLevel: "Beginner",
        imageUrl: "/attached_assets/stock_images/mathematics_equation_cf3eca2f.jpg",
        resourceType: "Interactive Tutorial",
      },
      {
        title: "Organic Chemistry Fundamentals",
        description: "Comprehensive introduction to organic chemistry including molecular structure, bonding, functional groups, and reaction mechanisms. Features laboratory techniques, safety procedures, and practical applications in medicine and industry.",
        category: "Science",
        skillLevel: "Intermediate",
        imageUrl: "/attached_assets/stock_images/science_laboratory_c_0d5e6746.jpg",
        resourceType: "Video Series",
        videoUrl: "https://www.youtube.com/watch?v=bSMS3EdsEaA",
      },
      {
        title: "Introduction to Physics",
        description: "Basic physics concepts including motion, forces, energy, and matter. Perfect for beginners with hands-on experiments, real-world examples, and clear visual demonstrations to make physics accessible and engaging.",
        category: "Science",
        skillLevel: "Beginner",
        imageUrl: "/attached_assets/stock_images/science_laboratory_c_24a5b389.jpg",
        resourceType: "eBook",
      },
      {
        title: "Spanish for Travelers",
        description: "Essential Spanish phrases and vocabulary for travel. Learn conversational skills, pronunciation, and cultural insights. Includes audio lessons, practice dialogues, and common scenarios like ordering food and asking directions.",
        category: "Languages",
        skillLevel: "Beginner",
        imageUrl: "/attached_assets/stock_images/languages_learning_b_ce171d01.jpg",
        resourceType: "Audio Course",
      },
      {
        title: "Advanced French Grammar",
        description: "Deep dive into complex French grammar including subjunctive mood, conditional tenses, and advanced sentence structures. For intermediate to advanced learners seeking fluency with detailed explanations and extensive exercises.",
        category: "Languages",
        skillLevel: "Advanced",
        imageUrl: "/attached_assets/stock_images/languages_learning_b_5bc24eae.jpg",
        resourceType: "Textbook",
      },
      {
        title: "Business Fundamentals",
        description: "Introduction to core business concepts including marketing, finance, operations, and management. Learn essential skills for entrepreneurs and business professionals with case studies and practical frameworks.",
        category: "Business",
        skillLevel: "Beginner",
        imageUrl: "/attached_assets/stock_images/business_economics_f_3382a144.jpg",
        resourceType: "Online Course",
      },
      {
        title: "Financial Analysis and Modeling",
        description: "Advanced techniques for financial statement analysis, valuation, and Excel-based financial modeling. Designed for finance professionals and analysts with real-world examples from corporate finance and investment banking.",
        category: "Business",
        skillLevel: "Advanced",
        imageUrl: "/attached_assets/stock_images/business_economics_f_08235ca0.jpg",
        resourceType: "Professional Workshop",
      },
      {
        title: "Drawing Basics for Beginners",
        description: "Learn fundamental drawing techniques including perspective, shading, proportion, and composition. Start with simple shapes and progress to complex subjects with step-by-step instructions and visual examples.",
        category: "Arts",
        skillLevel: "Beginner",
        imageUrl: "/attached_assets/stock_images/art_design_creative__d6ce82bd.jpg",
        resourceType: "Tutorial Series",
      },
      {
        title: "Digital Art Masterclass",
        description: "Advanced digital illustration and painting techniques using industry-standard software. Covers color theory, lighting, texture, and professional workflows for creating stunning digital artwork and commercial illustrations.",
        category: "Arts",
        skillLevel: "Advanced",
        imageUrl: "/attached_assets/stock_images/art_design_creative__647069eb.jpg",
        resourceType: "Video Course",
      },
    ];

    seedResources.forEach((resource) => {
      const id = randomUUID();
      this.resources.set(id, { ...resource, id });
    });
  }

  async getAllResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }

  async getResource(id: string): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = randomUUID();
    const resource: Resource = { ...insertResource, id };
    this.resources.set(id, resource);
    return resource;
  }

  async updateResource(id: string, insertResource: InsertResource): Promise<Resource | undefined> {
    const existing = this.resources.get(id);
    if (!existing) {
      return undefined;
    }
    const updated: Resource = { ...insertResource, id };
    this.resources.set(id, updated);
    return updated;
  }

  async deleteResource(id: string): Promise<boolean> {
    return this.resources.delete(id);
  }
}

export const storage = new MemStorage();
