import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const skillLevels = ["Beginner", "Intermediate", "Advanced"] as const;
export const categories = [
  "Programming",
  "Mathematics",
  "Science",
  "Languages",
  "Business",
  "Arts"
] as const;

export const resources = pgTable("resources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  skillLevel: text("skill_level").notNull(),
  imageUrl: text("image_url").notNull(),
  resourceType: text("resource_type").notNull(),
  videoUrl: text("video_url"),
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
}).extend({
  title: z.string().min(1, "Title is required").max(200, "Title is too long"),
  description: z.string().min(10, "Description must be at least 10 characters").max(1000, "Description is too long"),
  category: z.enum(categories, { errorMap: () => ({ message: "Please select a valid category" }) }),
  skillLevel: z.enum(skillLevels, { errorMap: () => ({ message: "Please select a valid skill level" }) }),
  imageUrl: z.string().url("Must be a valid URL"),
  resourceType: z.string().min(1, "Resource type is required"),
  videoUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;
export type SkillLevel = typeof skillLevels[number];
export type Category = typeof categories[number];
